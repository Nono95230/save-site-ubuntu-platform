<?php

/* themes/custom/bootstrap_child/templates/paragraph--ptype-experience-pro.html.twig */
class __TwigTemplate_cd8c872bfa2a2a0b34ea9cff0badbd5a64aceb4728150c6259be292f8a6cb170 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'paragraph' => array($this, 'block_paragraph'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("set" => 43, "block" => 51, "if" => 59);
        $filters = array("clean_class" => 45);
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('set', 'block', 'if'),
                array('clean_class'),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 41
        echo "
";
        // line 43
        $context["classes"] = array(0 => "paragraph", 1 => ("paragraph--type--" . \Drupal\Component\Utility\Html::getClass($this->getAttribute(        // line 45
($context["paragraph"] ?? null), "bundle", array()))), 2 => ((        // line 46
($context["view_mode"] ?? null)) ? (("paragraph--view-mode--" . \Drupal\Component\Utility\Html::getClass(($context["view_mode"] ?? null)))) : ("")));
        // line 49
        echo "

";
        // line 51
        $this->displayBlock('paragraph', $context, $blocks);
    }

    public function block_paragraph($context, array $blocks = array())
    {
        // line 52
        echo "  <div";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["attributes"] ?? null), "addClass", array(0 => ($context["classes"] ?? null)), "method"), "html", null, true));
        echo ">
    ";
        // line 53
        $this->displayBlock('content', $context, $blocks);
        // line 72
        echo "  </div>
";
    }

    // line 53
    public function block_content($context, array $blocks = array())
    {
        // line 54
        echo "      <div class=\"ptype-xp-pro-header-items\">
        <div class=\"ptype-xp-pro-header-item xp-pro-header-enterprise\">";
        // line 55
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["content"] ?? null), "field_xp_pro_enterprise", array()), "html", null, true));
        echo "</div>
        <div class=\"ptype-xp-pro-header-item xp-pro-header-date\">
          ";
        // line 57
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["content"] ?? null), "field_xp_pro_date_start", array()), "html", null, true));
        echo "
          <span> à </span>
          ";
        // line 59
        if (($this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_xp_pro_current_job", array()), "0", array(), "array"), "#markup", array(), "array") == "false")) {
            // line 60
            echo "            ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["content"] ?? null), "field_xp_pro_date_end", array()), "html", null, true));
            echo "
          ";
        } else {
            // line 62
            echo "            <span>aujourd'hui</span>
          ";
        }
        // line 64
        echo "        </div>
        <div class=\"ptype-xp-pro-header-item xp-pro-header-job_name\">";
        // line 65
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["content"] ?? null), "field_xp_pro_job_name", array()), "html", null, true));
        echo "</div>
      </div>
      <div class=\"ptype-xp-pro-content-item\">
        ";
        // line 68
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["content"] ?? null), "field_job_description", array()), "html", null, true));
        echo "
        ";
        // line 69
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["content"] ?? null), "field_xp_pro_environment_tech", array()), "html", null, true));
        echo "
      </div>
    ";
    }

    public function getTemplateName()
    {
        return "themes/custom/bootstrap_child/templates/paragraph--ptype-experience-pro.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  115 => 69,  111 => 68,  105 => 65,  102 => 64,  98 => 62,  92 => 60,  90 => 59,  85 => 57,  80 => 55,  77 => 54,  74 => 53,  69 => 72,  67 => 53,  62 => 52,  56 => 51,  52 => 49,  50 => 46,  49 => 45,  48 => 43,  45 => 41,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/bootstrap_child/templates/paragraph--ptype-experience-pro.html.twig", "/home/nono95230/sites/cgd/web/themes/custom/bootstrap_child/templates/paragraph--ptype-experience-pro.html.twig");
    }
}
